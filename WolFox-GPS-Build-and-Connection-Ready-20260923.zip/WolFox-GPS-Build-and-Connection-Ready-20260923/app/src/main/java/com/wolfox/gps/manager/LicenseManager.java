package com.wolfox.gps.manager;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.wolfox.gps.model.HistoryEntry;
import com.wolfox.gps.util.WFStorage;

import java.lang.ref.WeakReference;
import java.util.Locale;

/** Local static license gate for educational purposes. */
public final class LicenseManager {
    private static final LicenseManager INSTANCE = new LicenseManager();
    private static final String STATIC_EDU_CODE = "QWERASDFZXCV8547";
    private static final long MONITOR_INTERVAL_MS = 30000L;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WeakReference<Activity> monitorActivity = new WeakReference<>(null);
    private final Runnable monitorTask = new Runnable() {
        @Override public void run() {
            Activity activity = monitorActivity.get();
            if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;
            refresh(activity, true);
            main.postDelayed(this, MONITOR_INTERVAL_MS);
        }
    };

    public interface Callback {
        void onResult(boolean active, String status, String message);
    }

    private LicenseManager() {}

    public static LicenseManager getInstance() { return INSTANCE; }

    public boolean isActive(Context context) {
        return context != null && WFStorage.getInstance(context).isLicenseActive();
    }

    public void startSessionMonitoring(Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        monitorActivity = new WeakReference<>(activity);
        main.removeCallbacks(monitorTask);
        refresh(activity, true);
        main.postDelayed(monitorTask, MONITOR_INTERVAL_MS);
    }

    public void stopSessionMonitoring(Activity activity) {
        Activity owner = monitorActivity.get();
        if (owner == null || owner == activity) {
            main.removeCallbacks(monitorTask);
            monitorActivity.clear();
        }
    }

    public void refreshIfDue(Activity activity) {
        refresh(activity, false);
    }

    private void refresh(Activity activity, boolean force) {
        if (activity == null || activity.isFinishing()) return;
        WFStorage storage = WFStorage.getInstance(activity);
        
        // التحقق محلياً فقط من أن الكود المخزن يطابق الكود التعليمي
        if (!storage.isLicenseActive() || !STATIC_EDU_CODE.equals(storage.getLicenseCode())) {
            enforceInactive(activity);
        }
    }

    public void activate(Activity activity, String rawCode, Callback callback) {
        request(activity, rawCode, "activate", callback);
    }

    public void verify(Activity activity, String rawCode, Callback callback) {
        request(activity, rawCode, "verify", callback);
    }

    private void request(Activity activity, String rawCode, String requestMode, Callback callback) {
        if (activity == null || activity.isFinishing()) return;

        final String code = rawCode == null ? ""
                : rawCode.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.US);

        if (code.isEmpty()) {
            post(activity, callback, false, "InvalidRequest", "أدخل كود التفعيل");
            return;
        }

        final Context app = activity.getApplicationContext();
        final WFStorage storage = WFStorage.getInstance(app);

        // التحقق من مطابقة الكود الثابت
        if (STATIC_EDU_CODE.equals(code)) {
            long tenYearsMillis = 10L * 365 * 24 * 60 * 60 * 1000;
            long expiresEpoch = System.currentTimeMillis() + tenYearsMillis;

            storage.saveLicense(code, "Active", expiresEpoch, "2036-11-13 00:00:00");
            storage.addHistory(new HistoryEntry(
                    HistoryEntry.Action.ACTIVATE, "تم التفعيل محلياً (وضع تعليمي)"));

            post(activity, callback, true, "Active", "تم التفعيل بنجاح");
        } else {
            post(activity, callback, false, "InvalidCode", "كود التفعيل غير صحيح");
        }
    }

    private static void enforceInactive(Activity activity) {
        GPSMockManager.getInstance().stopMocking();
        com.wolfox.gps.ui.WolFoxPanel.dismiss();
        com.wolfox.gps.ui.MapDialog.dismiss();
        FloatingManager.getInstance().show(activity);
        com.wolfox.gps.ui.ActivationDialog.showRequired(activity);
    }

    private static void post(Activity activity, Callback callback, boolean active,
                             String status, String message) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (callback != null) callback.onResult(active, status, message);
            }
        });
    }
}
